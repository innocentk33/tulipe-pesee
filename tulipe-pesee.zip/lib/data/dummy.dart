import 'package:fish_scan/models/article.dart';
import 'package:fish_scan/models/commande.dart';
import 'package:fish_scan/models/tracabilite.dart';

List<Tracabilite> tracabilites = [];
