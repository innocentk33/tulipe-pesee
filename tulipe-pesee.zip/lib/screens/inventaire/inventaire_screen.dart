import 'package:flutter/material.dart';

class InventaireScreen extends StatefulWidget {
  @override
  _InventaireScreenState createState() => _InventaireScreenState();
}

class _InventaireScreenState extends State<InventaireScreen> {
  @override
  Widget build(BuildContext context) {
    return Container(

    );
  }
}
