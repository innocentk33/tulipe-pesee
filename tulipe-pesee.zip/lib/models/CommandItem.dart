class CommandItem{
  int index;
  int nbre;
  double poids;

  CommandItem(this.index, this.nbre, this.poids);
}