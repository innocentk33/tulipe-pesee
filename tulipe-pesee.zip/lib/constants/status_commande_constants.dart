class StatusCommandeConstants{
  static const String DEMANDE_PREPARATION = "demande_preparation";
  static const String CONFIRMATION = "Confirmation";
  static const String EN_COURS_PREPARATION = "En_cours_preparation";
  static const String DEPOTAGE = "true";
  static const String VENTE_MODIFICATION = "commande_modifie";
}