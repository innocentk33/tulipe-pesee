import 'package:flutter/cupertino.dart';

class Strings{
  static final String LOT_ENREGISTRE = "Un lot avec cette référence est déjà enregistré";
}

// LISTE DES COLORS
final Color kVert = Color(0XFF2e7940);
final Color kRose = Color(0XFFca1961);