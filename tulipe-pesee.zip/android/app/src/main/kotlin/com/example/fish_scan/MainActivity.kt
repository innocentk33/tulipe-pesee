package com.example.fish_scan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
